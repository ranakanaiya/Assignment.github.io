=================
Awesome Business THEME
=================
Contributors: themeansar
Tags: three-columns, right-sidebar, custom-colors, custom-logo, featured-images, full-width-template, threaded-comments, blog, e-commerce, news
Requires at least: 4.0.5
Tested up to: 4.8.1
Stable tag: 1.0

== Theme License & Copyright ==
Awesome Business is distributed under the terms of the GNU GPL
Awesome Business -Copyright 2018 Awesome Business, themeansar.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.



=================
SHORT DESCRIPTION
=================
Awesome Business WordPress theme ideal for a business or blog website (corporate, Consulting, Advisor, Agency, Finance, consult, law, Photography, freelancers, online presence etc.). You can also use for anything. It comes with all features these kind of Google Fonts, logo upload, slider, service, blog, shop page, latest news, about us, portfolio, contact us and much more. The theme you can use for any business website. Work with the most popular page builders as SiteOrigin. Developers will love his extensible codebase making it a joy to customize and extend. Looking for a Multi-Purpose theme? Look no further! Check the demos to realize that it's the only theme you will ever need: https://themeansar.com/demo/wp/businessup/transparent/


===========
ABOUT THEME
=========== 
Theme has two, three, four footer layout feature.We focused on usability across various
devices, starting with smart phones.it is compatible with various devices. Awesome Business is a
Cross-Browser Compatible theme that works on All leading web browsers. Awesome Business is easy to use and 
user friendly theme. Awesome Business has boxed and full-width layout feature.
Powerful but simple Awesome Business theme content customized through customizer. to make your site attractive it has two 
widget sections first for �sidebar widget section� and second for �Footer widget section� . 

To make your website in two column use sidebar widget section. to set custom menu in header set primary location. we added social media links to added your social links.It boasts of beautifully designed page sections , Home, Blog and Default Page Template(page with right sidebar), Page Full-Width, Page Left Sidebar. Awesome Business theme has more advanced feature to make your site awesome like: it has header top bar dark & lite color feature. you can also changed header color dark and lite styling. Theme compatible with woocommerce. Awesome Business is a fully woocommerce tested theme. Awesome Business is translation ready theme with WPML compatible & Many More�.

Businessup WordPress Theme, Copyright 2017 Themeansar
Businessup is distributed under the terms of the GNU General Public License v2 

Awesome Business WordPress Theme is the child theme of businessup, Copyright 2018 themeansar
Awesome Business is distributed under the terms of the GNU General Public License v2 


Supported browsers: Firefox, Opera, Chrome, Safari and IE10+ (Some css3 styles like shadows, rounder corners and 2D transform are not supported by IE8 and below).

/***** BUNDELED CSS ***/
============================================
This theme uses Underscores
============================================
 * Awesome Business is based on Underscores. All the files in the theme package are from Underscores, unless stated otherwise.
 * Copyright: Automattic, automattic.com
 * Source: http://underscores.me/
 * License: GPLv2
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html

/**** Images Source *****/

============================================
All images use Pixabay
============================================
	/***** Screenshot Image *****/
	Screenshot & Banner Image : CCO by Pixabay rawpixel :
	1. https://pixabay.com/en/analyzing-brainstorming-business-3385076/
========================================================================================	
--- Version 1.0 ----
1. Relesed